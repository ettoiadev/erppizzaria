"use client"

import { PDVInterface as PDVInterfaceRefactored } from './pdv-interface-refactored'

// Re-export the refactored component
export function PDVInterface() {
  return <PDVInterfaceRefactored />
}