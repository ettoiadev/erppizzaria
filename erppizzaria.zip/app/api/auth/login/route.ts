import { NextRequest, NextResponse } from "next/server"
import { frontendLogger } from '@/lib/frontend-logger'
import { loginUser } from '@/lib/auth'
import { appLogger } from '@/lib/logging'
import { userLoginSchema } from '@/lib/validation-schemas'
import { addCorsHeaders, createOptionsHandler } from '@/lib/auth-utils'
import { validateAndSanitizeDataDirect, createValidationErrorResponse } from '@/lib/validation-utils'
import { applyRateLimit, createRateLimitErrorResponse } from '@/lib/rate-limit-utils'

export const dynamic = 'force-dynamic'

export async function GET() {
  const response = NextResponse.json({ message: "Login endpoint is working", timestamp: new Date().toISOString(), method: "GET" })
  return addCorsHeaders(response)
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    // 1. Rate Limiting
    const rateLimitResult = await applyRateLimit(request, 'auth')
    if (!rateLimitResult.success) {
      return createRateLimitErrorResponse(rateLimitResult)
    }

    // 2. Validação e Sanitização
    const body = await request.json()
    const validationResult = await validateAndSanitizeDataDirect(body, userLoginSchema)
    if (!validationResult.success) {
      return createValidationErrorResponse(validationResult.error || 'Dados inválidos')
    }

    const validatedData = validationResult.data as { email: string; password: string }
    
    // 3. Logging da requisição
    appLogger.info('auth', 'Login request received', { email: validatedData.email.replace(/(.{2}).*(@.*)/, '$1***$2') })
    
    const { email, password } = validatedData

    // 4. Verificar se é um login administrativo
    const isAdminLogin = request.url.includes('/admin/login') || request.headers.get('x-admin-login') === 'true'

    // 5. Realizar login usando o novo sistema de autenticação
    const authResult = await loginUser(email, password)
    
    // 6. Verificar permissões administrativas se necessário
    if (isAdminLogin && authResult.user.role !== 'admin') {
      appLogger.warn('auth', 'Tentativa de login administrativo com usuário não autorizado', {
        email: email.replace(/(.{2}).*(@.*)/, '$1***$2'),
        role: authResult.user.role
      })
      return NextResponse.json({ error: "Acesso não autorizado" }, { status: 403 })
    }

    // 7. Login bem-sucedido
    appLogger.info('auth', 'Login realizado com sucesso', {
      email: email.replace(/(.{2}).*(@.*)/, '$1***$2'),
      role: authResult.user.role
    })

    // 8. Retornar resposta com JWT token
    const response = NextResponse.json({
      success: true,
      user: {
        id: authResult.user.id,
        email: authResult.user.email,
        full_name: authResult.user.full_name,
        role: authResult.user.role,
        phone: authResult.user.phone
      },
      token: authResult.token
    })

    // 9. Adicionar cookie de autenticação JWT
    response.cookies.set('auth-token', authResult.token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 60 * 60 // 7 dias
    })

    return addCorsHeaders(response)

  } catch (error: any) {
    appLogger.error('auth', 'Erro interno no login', error)
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    )
  }
}

export const OPTIONS = createOptionsHandler()