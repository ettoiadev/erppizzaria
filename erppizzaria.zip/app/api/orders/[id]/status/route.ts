import { NextRequest, NextResponse } from "next/server"
import { query } from '@/lib/database'
import { frontendLogger } from '@/lib/frontend-logger'
import { validateAdminAuth, createAuthErrorResponse, addCorsHeaders } from '@/lib/auth-utils'
import { z } from 'zod'

// Schema para validação de atualização de status
const orderStatusUpdateSchema = z.object({
  status: z.enum(['RECEIVED', 'PREPARING', 'READY', 'ON_THE_WAY', 'DELIVERED', 'CANCELLED']),
  notes: z.string().optional()
})

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  // Validar autenticação de admin
  const authResult = await validateAdminAuth(request)
  if (!authResult.success) {
    return createAuthErrorResponse(authResult.error || 'Acesso negado', 401)
  }
  
  const admin = authResult.user
  if (!admin) {
    return createAuthErrorResponse('Usuário não encontrado', 401)
  }

  try {
    const orderId = params.id
    
    frontendLogger.info('Iniciando atualização de status do pedido', 'api', {
      adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
      orderId
    });

    // Parse do JSON
    let body
    try {
      body = await request.json()
    } catch (error) {
      frontendLogger.warn('JSON inválido na atualização de status', 'api', {
        adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
        orderId
      });
      const response = NextResponse.json({ error: "JSON inválido" }, { status: 400 })
      return addCorsHeaders(response)
    }

    // Validação usando Zod
    const validationResult = orderStatusUpdateSchema.safeParse(body)
    if (!validationResult.success) {
      frontendLogger.warn('Dados inválidos na atualização de status', 'api', {
        adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
        orderId,
        errors: validationResult.error.errors
      });
      const response = NextResponse.json({ 
        error: "Dados inválidos", 
        details: validationResult.error.errors 
      }, { status: 400 })
      return addCorsHeaders(response)
    }

    const { status, notes } = validationResult.data

    // Buscar pedido atual para validar transição de status
    const currentOrderResult = await query(
      'SELECT id, status FROM orders WHERE id = $1',
      [orderId]
    )
    
    if (currentOrderResult.rows.length === 0) {
      frontendLogger.warn('Pedido não encontrado para atualização de status', 'api', {
        adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
        orderId
      });
      const response = NextResponse.json({ error: "Pedido não encontrado" }, { status: 404 })
      return addCorsHeaders(response)
    }
    
    const currentOrder = currentOrderResult.rows[0]

    // Validar transição de status
    const statusOrder = ['RECEIVED', 'PREPARING', 'READY', 'ON_THE_WAY', 'DELIVERED']
    const currentIndex = statusOrder.indexOf(currentOrder.status)
    const newIndex = statusOrder.indexOf(status)

    if (newIndex < currentIndex && status !== 'CANCELLED') {
      frontendLogger.warn('Tentativa de regressão de status inválida', 'api', {
        adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
        orderId,
        currentStatus: currentOrder.status,
        newStatus: status
      });
      const response = NextResponse.json({ error: "Não é possível voltar o status do pedido" }, { status: 400 })
      return addCorsHeaders(response)
    }

    // Atualizar status do pedido
    const updateFields = ['status = $1', 'updated_at = $2']
    const updateValues = [status, new Date().toISOString()]
    let paramIndex = 3
    
    if (notes) {
      updateFields.push(`notes = $${paramIndex++}`)
      updateValues.push(notes)
    }
    
    updateValues.push(orderId) // Para o WHERE
    
    const updateQuery = `
      UPDATE orders 
      SET ${updateFields.join(', ')}
      WHERE id = $${paramIndex}
      RETURNING *
    `
    
    const updateResult = await query(updateQuery, updateValues)
    const updatedOrder = updateResult.rows[0]

    frontendLogger.info('Status do pedido atualizado com sucesso', 'api', {
      adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
      orderId,
      previousStatus: currentOrder.status,
      newStatus: status,
      hasNotes: !!notes
    });

    // Log da atualização de status (removido sistema realtime)
    frontendLogger.info('Status do pedido atualizado - evento registrado', 'api', {
      adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
      orderId,
      event: 'order_status_updated'
    });

    const response = NextResponse.json({
      message: "Status atualizado com sucesso",
      order: updatedOrder
    })
    return addCorsHeaders(response)

  } catch (error: any) {
    frontendLogger.logError('Erro ao atualizar status do pedido', {
      adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
      orderId: params.id
    }, error, 'api');
    
    const response = NextResponse.json({
      error: "Erro interno do servidor",
      message: "Erro ao atualizar status do pedido",
      details: error.message
    }, { status: 500 })
    return addCorsHeaders(response)
  }
}

// Handle DELETE requests (redirect to PATCH with CANCELLED status)
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  // Validar autenticação de admin
  const authResult = await validateAdminAuth(request)
  if (!authResult.success) {
    return createAuthErrorResponse(authResult.error || 'Acesso negado', 401)
  }
  
  const admin = authResult.user
  if (!admin) {
    return createAuthErrorResponse('Usuário não encontrado', 401)
  }

  try {
    frontendLogger.info('Iniciando cancelamento de pedido via DELETE', 'api', {
      adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
      orderId: params.id
    });
    
    // Parse body to get cancellation notes if provided
    let notes = null
    try {
      const body = await request.json()
      notes = body.notes || body.motivoCancelamento || null
      if (notes) {
        frontendLogger.info('Notas de cancelamento fornecidas', 'api', {
          adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
          orderId: params.id
        });
      }
    } catch (parseError) {
      frontendLogger.info('Nenhuma nota de cancelamento fornecida', 'api', {
        adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
        orderId: params.id
      });
    }

    // Create a new request with PATCH method
    const patchRequest = new NextRequest(request.url, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': request.headers.get('Authorization') || ''
      },
      body: JSON.stringify({ 
        status: 'CANCELLED', 
        notes: notes 
      })
    })

    // Call the PATCH handler
    return await PATCH(patchRequest, { params })
  } catch (error: any) {
    frontendLogger.logError('Erro ao cancelar pedido via DELETE', {
      adminEmail: admin.email.replace(/(.{2}).*(@.*)/, '$1***$2'),
      orderId: params.id
    }, error, 'api');
    
    const response = NextResponse.json({ 
      error: error.message || "Erro interno do servidor",
      details: {
        type: error.constructor.name,
        message: error.message
      }
    }, { status: 500 })
    return addCorsHeaders(response)
  }
}