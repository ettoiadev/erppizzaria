import { query, checkConnection } from '@/lib/postgresql';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Verificar variáveis de ambiente
    const envCheck = {
      POSTGRES_HOST: !!process.env.POSTGRES_HOST,
      POSTGRES_PORT: !!process.env.POSTGRES_PORT,
      POSTGRES_DB: !!process.env.POSTGRES_DB,
      POSTGRES_USER: !!process.env.POSTGRES_USER,
      POSTGRES_PASSWORD: !!process.env.POSTGRES_PASSWORD,
      DATABASE_URL: !!process.env.DATABASE_URL,
      JWT_SECRET: !!process.env.JWT_SECRET,
    };

    // Testar conexão com PostgreSQL
    const connectionTest = await checkConnection();
    
    if (!connectionTest.success) {
      console.error('PostgreSQL connection error:', connectionTest.error);
      return NextResponse.json(
        {
          status: 'error',
          message: 'Database connection failed',
          error: connectionTest.error,
          environment: envCheck,
        },
        { status: 500 }
      );
    }

    // Testar uma query simples
    const testResult = await query('SELECT 1 as test');

    return NextResponse.json({
      status: 'ok',
      message: 'API is healthy',
      timestamp: new Date().toISOString(),
      environment: envCheck,
      postgresql: {
        connected: true,
        test_query: 'success',
        version: connectionTest.version,
      },
    });
  } catch (error) {
    console.error('Health check error:', error);
    return NextResponse.json(
      {
        status: 'error',
        message: 'Health check failed',
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

export async function POST() {
  return NextResponse.json({
    message: 'Health check - POST method working',
    timestamp: new Date().toISOString()
  });
}